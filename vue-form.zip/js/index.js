Vue.component('post-title', {
  props: ['title'],
  template: '<p>{{ title }}</p>' });

Vue.component('post-text', {
  props: ['text'],
  template: '<p>{{ text }}</p>' });

Vue.component('post-form', {
  props: ['Title', 'Text', 'add'],
  template: '<div id="post-form">\n    <label for="inputTitle">Title:</label><input v-model="Title" id="inputTitle" @keypress.enter="add">\n    \n    <label for="inputText">Text:</label><input v-model="Text" id="inputText" @keypress.enter="add">\n    <div class="button">\n    <button @click="add(Title, Text)" type="button" class="sbmbtn">add</button>\n    </div>\n</div>\n' });

Vue.component('input-n-post', {
  template: '\n<div id="post-form">    \n    <post-form :add="add" :Title="inputTitle" :Text="inputText"/>\n    <div v-if="items.length==0">\u041D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439</div>\n    <div v-else v-for="(item, index) in items">\n    <h3\n      is="post-title"\n      :key="item.index"\n      :title="item.title"\n      ></h3>\n    <div  \n      is="post-text"\n      :key="item.index"\n      :text="item.text"\n    ></div>\n    </div>\n</div>\n',
  data: function data() {
    return {
      inputText: null,
      inputTitle: null,
      items: [] };
  },
  methods: {
    add: function add(inputTitle, inputText) {
      this.items.push({ title: inputTitle });
      this.inputTitle = '';
      this.items.push({ text: inputText });
      this.inputText = '';
    } } });
new Vue({
  el: "#app" });