const {get} = require('axios')
require('should')

const headers = {'Content-Type':'application/json'}
let bRes, cases;

const bReq = async(a) => {
   await get(`http://kodaktor.ru/api2/there/${a}`,{headers})
       .then((data)=>{
           bRes = data.data
           return data.data
       })
}

const resp = async (a)=>{
    await bReq(a);
     cases = {a:a, get b(){return bRes}}
    return cases
}

let bRes2, cases2;
const bReq2 = async(a) => {
    await get(`http://kodaktor.ru/api2/andba/${a}`,{headers})
        .then((data)=>{
            bRes2 = data.data
            return data.data
        })
}

const resp2 = async (a)=>{
    await bReq2(a);
    cases2 = {a:a, get b(){return bRes2}}
    return cases2
}

const range = (start, end) => new Array(end - start + 1)
    .fill(undefined).map((value, index) => index + start)
let arrOfNum = range(0,100)
arrOfNum.forEach((a)=>{
    describe('tests for microservices', ()=>{
        it(`respond a = ${a}`, async ()=>{

            await resp(a)
            await resp2(bRes)

            let andbaB = cases2.b,
                thereA  = cases.a,
                andbaA = cases2.a,
                thereB  = cases.b


            thereA.should.equal(andbaB)
            thereB.should.equal(andbaA)
            console.log(`cases2.b = ${andbaB} cases.a = ${thereA}`)
            console.log(`cases2.b = ${andbaA} cases.a = ${thereB}`)

        })
    })
})